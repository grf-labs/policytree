library(testthat)
library(policytree)

options(warn = 2) # warnings are errors
test_check("policytree")
